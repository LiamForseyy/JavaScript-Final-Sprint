fetch('./people.json')
  .then(response => response.json())
  .then(data => {
    
    data.forEach(person => {
      console.log(getFullName(person));
      console.log(getAge(person));
      console.log(getSalary(person));
    });

    var outputDiv = document.getElementById('output');

    
    if (outputDiv) {
      
      data.forEach(person => {
        
        var paragraph = document.createElement('p');

        
        paragraph.textContent = `Hello, my name is ${getFullName(person)}, I am ${getAge(person)} years old and I'm currently making ${getSalary(person)} per year.`;

        
        outputDiv.appendChild(paragraph);
      });
    } else {
      console.error('Output div not found.');
    }
  })
  .catch(error => {
    
    console.error(error);

  })
  .catch(error => {
   
    console.error(error);
  });

  function getFullName(person) {
    return `${person.fname} ${person.lname}`;
  }

  function getAge(person){
    return person.age;
  }
  
  function getSalary(person){
    return person.salary;
  }

